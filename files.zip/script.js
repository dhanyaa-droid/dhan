document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("welcome-modal");
  const closeBtn = document.getElementById("close-modal");

  // Show modal on load
  setTimeout(() => {
    modal.classList.remove('hide');
  }, 200);

  closeBtn.onclick = function () {
    modal.classList.add('hide');
  };

  // Also close modal if user clicks outside the modal content
  modal.onclick = function (e) {
    if (e.target === modal) {
      modal.classList.add('hide');
    }
  };
});